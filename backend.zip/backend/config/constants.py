PRODUCT_TYPE = (
    ('male', 'Male'),
    ('female', 'Female'),
)
